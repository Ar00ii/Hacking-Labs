# Can You Hack Me? — The Hackers Labs

**Autor:** Carlos de la Cruz · ASIX 2
**Dificultad:** Media · **Plataforma:** The Hackers Labs

> Resumen de la intrusión: dominio virtual en `/etc/hosts` → usuario filtrado en un comentario HTML → fuerza bruta SSH → escalada de privilegios abusando del grupo `docker`.

---

## 1. Reconocimiento de puertos

Escaneamos la máquina víctima y detectamos los puertos **22 (SSH)** y **80 (Web)** abiertos. El servidor web no responde con la IP directa, sino que **redirige al dominio `canyouhackme.thl`**.

![Escaneo Nmap](images/01-nmap.png)

Como ese dominio no existe en internet, lo añadimos manualmente a nuestro `/etc/hosts` apuntando a la IP de la máquina para poder cargar la página.

```bash
echo '10.0.2.19 canyouhackme.thl' >> /etc/hosts
```

![Edición de /etc/hosts](images/02-hosts.png)

---

## 2. Usuario filtrado en el código fuente

Cargada la web (la de las letras verdes estilo Matrix), inspeccionamos el código fuente y encontramos un **comentario olvidado por un desarrollador**: *"Hola juan, te he dejado un correo..."*. Esto nos da un **nombre de usuario válido: `juan`**.

![Comentario con el usuario en el HTML](images/03-comentario.png)

---

## 3. Fuerza bruta SSH

Con el usuario `juan` y el puerto SSH abierto, atacamos con **Hydra** y `rockyou.txt`.

```bash
hydra -l juan -P /usr/share/wordlists/rockyou.txt ssh://10.0.2.19
```

Hydra revela la contraseña: **`matrix`**.

![Fuerza bruta SSH con Hydra](images/04-hydra.png)

---

## 4. Primera flag (user)

Nos conectamos por SSH como `juan` y leemos la **flag de usuario**.

![Flag de usuario](images/05-userflag.png)

---

## 5. Escalada de privilegios (grupo docker)

Ejecutamos `id` para revisar nuestros grupos y detectamos una vulnerabilidad crítica: **`juan` pertenece al grupo `docker`**. Pertenecer a ese grupo equivale a tener root, porque permite montar el sistema de archivos del host dentro de un contenedor.

![Comprobación del grupo docker con id](images/06-id-docker.png)

Lanzamos un contenedor de Alpine montando todo el disco del host (`-v /:/mnt`). Dentro del contenedor operamos como root absoluto, así que copiamos `/bin/bash` al directorio de `juan` y le aplicamos el bit **SUID** (`chmod u+s`):

```bash
docker run -it -v /:/mnt alpine sh
# dentro del contenedor:
cd /mnt
cp bin/bash home/juan
chmod u+s home/juan/bash
exit
```

![Explotación del contenedor docker](images/07-docker.png)

De vuelta como `juan`, ejecutamos el binario modificado con `-p` (preserva privilegios). Al tener SUID, nos otorga una shell como **root**:

```bash
./bash -p
whoami   # -> root
```

![Shell de root vía bash SUID](images/08-bash-suid.png)

---

## 6. Flag final (root)

Navegamos a `/root`, leemos `root.txt` con `cat` y capturamos la **flag final**. El sistema queda completamente comprometido.

![Flag de root](images/09-rootflag.png)

---

## Conclusión

Esta máquina muestra dos enseñanzas clásicas: la información sensible filtrada en comentarios del código fuente (un nombre de usuario) y el abuso del **grupo `docker`** como vector directo de escalada a root. Cualquier usuario en ese grupo puede montar el disco del host y comprometer toda la máquina, por lo que su asignación debe tratarse con el mismo cuidado que el acceso root.
