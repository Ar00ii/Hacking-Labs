# 📸 Guía para colocar las capturas

Cada informe ya tiene los huecos de imagen enlazados. Solo tienes que **guardar cada captura de tu PDF original** dentro de la carpeta `images/` de la máquina correspondiente, **con el nombre exacto** que se indica abajo (formato `.png`).

> Consejo: exporta o recorta cada captura del PDF original respetando el orden en que aparecen. La numeración (01, 02, 03...) sigue ese mismo orden.

---

## Inj3ctCrew/images/
- `01-nmap.png` — comando nmap
- `02-puertos.png` — resultado de puertos (22/80)
- `03-web-inspeccion.png` — web "SIGUE BUSCANDO" + inspector con el hash
- `04-base64.png` — decodificación Base64 ("directorio de respaldo...")
- `05-gobuster.png` — salida de gobuster (index/login/backup.php)
- `06-backupphp.png` — backup.php "PWNED DIRECTORY" inspeccionado
- `07-credenciales.png` — PwnedCredentials.html (Admin + hash)
- `08-crackstation.png` — CrackStation devuelve "qwerty"
- `09-login.png` — login.php
- `10-panel.png` — Panel de Control con ejecutar comandos
- `11-passwd.png` — salida de /etc/passwd (nolen11)
- `12-hydra.png` — hydra encuentra 987654321
- `13-userflag.png` — ssh + ls -la + cat user.txt
- `14-rootflag.png` — sudo find + cd /root + cat root.txt

## Dragon/images/
- `01-nmap.png` — comando nmap + resultado
- `02-web.png` — web "Bienvenido a la Máquina del Dragón"
- `03-gobuster-secret.png` — gobuster (secret) + página /secret
- `04-hydra.png` — hydra (dragon:shadow)
- `05-ssh-userflag.png` — ssh + ls + cat user.txt
- `06-sudo-l.png` — sudo -l (NOPASSWD vim)
- `07-vim-shell.png` — vim con :!/bin/bash
- `08-root.png` — prompt de root tras vim
- `09-rootflag.png` — ls /root + cat root.txt

## Bluemoon/images/
- `01-netdiscover.png` — comando netdiscover
- `02-netdiscover-result.png` — tabla de hosts (10.0.2.6)
- `03-nmap.png` — resultado nmap (21/22/80)
- `04-web-gobuster.png` — web "The Game Begins" + gobuster (hidden_text)
- `05-qr.png` — lectura del QR (credenciales FTP)
- `06-ftp.png` — conexión y get de los .txt
- `07-cat-hydra.png` — cat de los archivos + hydra (robin)
- `08-user1-sudo.png` — ssh robin + cat user1.txt + sudo -l
- `09-feedback.png` — ls/cat de feedback.sh + sudo -u jerry
- `10-user2.png` — whoami jerry + cd /home/jerry + cat user2.txt

## TickTackRoot/images/
- `01-nmap.png` — comando + resultado nmap (21/22/80)
- `02-web.png` — página por defecto de Apache2
- `03-ftp.png` — conexión FTP ("Bienvenido Robin")
- `04-hydra.png` — hydra (robin:babyblue)
- `05-userflag-sudo.png` — cat user.txt + sudo -l (timeout_suid)
- `06-rootflag.png` — sudo timeout_suid + cd /root + cat root.txt

## ZAPP/images/
- `01-nmap.png` — resultado nmap (21/22/80, título zappskred)
- `02-base64-html.png` — inspector con el Base64 + script bash64
- `03-chmod.png` — chmod +x bash64
- `04-resultado.png` — salida "cuatrocuatroveces"
- `05-rar.png` — index /cuatrocuatroveces + wget del .rar
- `06-john.png` — rar2john + john (reema)
- `07-unrar.png` — unrar + cat Sup3rP4ss.txt (3spuM4)
- `08-ssh-userflag.png` — ssh zappskred + cat user.txt
- `09-rootflag.png` — sudo /bin/zsh + whoami root + cat root.txt

## CanYouHackMe/images/
- `01-nmap.png` — nmap (22/80, redirección canyouhackme.thl)
- `02-hosts.png` — echo ... >> /etc/hosts
- `03-comentario.png` — inspector con "Hola juan..."
- `04-hydra.png` — hydra (juan:matrix)
- `05-userflag.png` — User flag
- `06-id-docker.png` — id (grupo docker)
- `07-docker.png` — docker run -v /:/mnt + cp + chmod u+s
- `08-bash-suid.png` — ./bash -p + whoami root
- `09-rootflag.png` — cd /root + cat root.txt

## Earth/images/
- `01-netdiscover.png` — comando netdiscover
- `02-netdiscover-result.png` — tabla de hosts (10.0.2.16)
- `03-nmap-badrequest.png` — nmap (22/80/443) + Bad Request 400
- `04-hosts.png` — echo earth.local / terratest.earth.local >> /etc/hosts
- `05-earth-local.png` — portal Earth Secure Messaging
- `06-terratest.png` — terratest.earth.local
- `07-login.png` — panel /admin/login + inspector
- `08-testingnotes.png` — /testingnotes.txt
- `09-robots.png` — /robots.txt
- `10-testdata.png` — /testdata.txt
- `11-cyberchef.png` — CyberChef XOR (earthclimatechangebad4humans)
- `12-admin-tool.png` — Admin Command Tool
- `13-rce.png` — cd /home; ls -al; pwd (RCE)
- `14-bloqueo.png` — "Remote connections are forbidden"
- `15-userflag.png` — cd /var/earth_web + cat user_flag.txt + listener
- `16-base64-shell.png` — echo nc... | base64 + conexión recibida
- `17-suid-resetroot.png` — find -perm -u=s + reset_root falla
- `18-ltrace.png` — ltrace reset_root (3 archivos)
- `19-triggers.png` — touch de los 3 archivos + reset OK
- `20-suroot.png` — su root + whoami + ls /
- `21-rootflag.png` — cat root_flag.txt

## Brocoli/images/
- `01-nmap.png` — comando + resultado nmap (22/80)
- `02-web.png` — página por defecto Apache2
- `03-base64-gobuster.png` — comentario Base64 + gobuster (/uploads)
- `04-base64-index.png` — decodificación Base64 + index /uploads
- `05-rce.png` — brocoli.php?cmd=id (www-data)
- `06-reverseshell.png` — URL con reverse shell codificada
- `07-penelope.png` — penelope.py captura la sesión
- `08-userflag.png` — ls + cat informebrocoli.txt
- `09-credenciales.png` — cat /opt/credenciales.txt
- `10-su-java.png` — su brocoli + Root.java + sudo java
- `11-rootflag.png` — cat /root/root.txt

## Fruits/images/
- `01-nmap.png` — comando nmap
- `02-web.png` — resultado nmap + web "Página de Frutas"
- `03-wfuzz.png` — wfuzz buscando .php (rabbit hole)
- `04-lfi.png` — wfuzz parámetro "file" + fruits.php?file=/etc/passwd
- `05-hydra-userflag.png` — hydra (bananaman:celtic) + cat user.txt
- `06-rootflag.png` — sudo find -exec /bin/sh + cd /root + cat root.txt

## PaQueAigaLujo/images/
- `01-nmap.png` — comando + resultado nmap (22/80)
- `02-web-comentarios.png` — Luxe Collection + comentarios (nombres)
- `03-hydra-ssh.png` — hydra + ssh Sophia
- `04-passwd.png` — cat /etc/passwd | grep sh (cipote)
- `05-ping-fscan.png` — bucle de ping + descarga de fscan
- `06-msf.png` — msfconsole + exploit drupalgeddon2
- `07-meterpreter.png` — sessions + getuid www-data
- `08-settings-ballenita.png` — grep settings.php + su ballenita
- `09-sudo-grep.png` — sudo -l + ls + grep del secreto
- `10-cipote.png` — ssh cipote + sudo -l (mount)
- `11-flags.png` — sudo mount + cat user.txt + cat root.txt
