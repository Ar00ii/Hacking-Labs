# 🛡️ Writeups CTF — Carlos de la Cruz (ASIX 2)

Colección de informes de resolución de máquinas **CTF** de las plataformas **The Hackers Labs** y **VulnHub**, realizados durante el curso. Cada writeup documenta el proceso completo: reconocimiento, explotación, acceso y escalada de privilegios.

> ⚠️ Todo el contenido es con fines **educativos** y de aprendizaje en entornos controlados y autorizados.

---

## 📂 Máquinas

| Máquina | Plataforma | Dificultad | Técnicas destacadas |
|---|---|---|---|
| [Inj3ctCrew](./Inj3ctCrew/) | The Hackers Labs | Media | Base64, backups expuestos, RCE web, `sudo find` |
| [Dragon](./Dragon/) | The Hackers Labs | Fácil/Media | Fuerza bruta SSH, `sudo vim` |
| [BlueMoon](./Bluemoon/) | VulnHub | Media | QR con credenciales, FTP, inyección en script |
| [TickTackRoot](./TickTackRoot/) | The Hackers Labs | Fácil/Media | FTP anónimo, SUID `timeout` |
| [ZAPP](./ZAPP/) | The Hackers Labs | Media | Base64 anidado, crackeo de `.rar`, `sudo zsh` |
| [Can You Hack Me?](./CanYouHackMe/) | The Hackers Labs | Media | Vhost, grupo `docker`, SUID bash |
| [Earth](./Earth/) | VulnHub | Media | Vhosts, cifrado XOR, RCE, SUID `reset_root` |
| [Brocoli](./Brocoli/) | The Hackers Labs | Media | Webshell PHP, reverse shell, `sudo java` |
| [Fruits](./Fruits/) | The Hackers Labs | Media | LFI, fuerza bruta SSH, `sudo find` |
| [Pa Que Aiga Lujo](./PaQueAigaLujo/) | The Hackers Labs | Alta | Pivoting Docker, Drupalgeddon2, `sudo mount` |

---

## 🧰 Herramientas utilizadas

`nmap` · `gobuster` · `wfuzz` · `hydra` · `john` · `netdiscover` · `ftp` · `metasploit` · `docker` · `cyberchef` · `ltrace` · `penelope`

---

## 📁 Estructura del repositorio

```
writeups/
├── README.md            <- este índice
├── Inj3ctCrew/
│   ├── README.md
│   └── images/          <- capturas de esta máquina
├── Dragon/
│   ├── README.md
│   └── images/
└── ...
```

Cada carpeta de máquina incluye su informe (`README.md`) y una carpeta `images/` con las capturas referenciadas en el texto.
