# BlueMoon — VulnHub

**Autor:** Carlos de la Cruz · ASIX 2
**Dificultad:** Media · **Plataforma:** VulnHub

> Resumen de la intrusión: descubrimiento de host → QR con credenciales FTP → diccionario personalizado para fuerza bruta SSH → escalada lateral vía script con `sudo` → segunda flag.

---

## 1. Descubrimiento del host

Como la IP no se conoce de antemano, usamos **netdiscover** para mapear los equipos vivos de la red local.

```bash
netdiscover -i eth0 -r 10.0.2.0/24
```

![Netdiscover](images/01-netdiscover.png)

El objetivo es **10.0.2.6**. Lanzamos un Nmap para enumerar sus servicios.

![Resultado de netdiscover](images/02-netdiscover-result.png)

Nmap revela **tres puertos abiertos**: **80 (HTTP)**, **22 (SSH)** y **21 (FTP)**. Empezamos por el web.

![Escaneo Nmap](images/03-nmap.png)

---

## 2. Enumeración web

La página principal ("Welcome / The Game Begins") no expone nada útil, ni siquiera inspeccionando. Lanzamos **Gobuster** y aparece la ruta `hidden_text`, que puede contener información valiosa.

```bash
gobuster dir -u http://10.0.2.6/ -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt
```

![Web inicial y Gobuster](images/04-web-gobuster.png)

---

## 3. Código QR con credenciales FTP

En `hidden_text` no hay nada a primera vista, pero el enlace "Thank You" redirige a una página con un **código QR**. Lo escaneamos con una herramienta online de lectura de códigos de barras.

![Lectura del código QR](images/05-qr.png)

El QR contiene un fragmento de script con **credenciales FTP**: usuario `userftp` y contraseña `ftpp@ssword`.

---

## 4. Acceso FTP y descarga de archivos

Nos conectamos por FTP con las credenciales obtenidas. Con `ls -la` encontramos dos archivos —`information.txt` y `p_lists.txt`— que descargamos a nuestra máquina con `GET`.

```bash
ftp 10.0.2.6
get information.txt
get p_lists.txt
```

![Conexión y descarga FTP](images/06-ftp.png)

---

## 5. Análisis de los archivos y fuerza bruta SSH

Al leer ambos archivos con `cat` descubrimos que `p_lists.txt` es una **lista de contraseñas candidatas** y que `information.txt` saluda a "ROBIN", revelando así un **nombre de usuario** válido.

Con ese usuario y la wordlist personalizada, atacamos SSH con **Hydra**.

```bash
hydra -l robin -P p_lists.txt ssh://10.0.2.6
```

Hydra encuentra la contraseña de `robin`: **`k4rv3ndh4nh4ck3r`**.

![Análisis de archivos y Hydra](images/07-cat-hydra.png)

---

## 6. Primera flag (user1)

Nos conectamos por SSH como `robin`, listamos con `ls -la` y leemos `user1.txt` para obtener la **primera flag**.

`sudo -l` revela que `robin` puede ejecutar **`/home/robin/project/feedback.sh` como el usuario `jerry`** sin contraseña.

![Flag user1 y sudo -l](images/08-user1-sudo.png)

---

## 7. Escalada lateral a jerry

Inspeccionamos el directorio `project`. Dentro está `feedback.sh`, un script que **guarda lo que escribe el usuario en una variable y la ejecuta** (`$feedback`). Esto equivale a una inyección de comandos.

![Análisis de feedback.sh](images/09-feedback.png)

Ejecutamos el script como `jerry` y, cuando pide el feedback, introducimos `/bin/bash`. Como la variable se ejecuta tal cual, obtenemos una shell con la identidad de `jerry`.

```bash
sudo -u jerry /home/robin/project/feedback.sh
```

---

## 8. Segunda flag (user2)

Con `whoami` confirmamos que somos `jerry`. Tras un `pwd`, nos movemos a su directorio personal (`cd /home/jerry`), listamos y leemos `user2.txt` con `cat` para capturar la **segunda flag**.

![whoami y flag user2](images/10-user2.png)

---

## Conclusión

BlueMoon combina exposición de credenciales por canales poco evidentes (un QR enlazado desde una página oculta) con una **inyección de comandos** en un script ejecutable vía `sudo` como otro usuario. La cadena ilustra la importancia de validar la entrada en scripts y de no almacenar credenciales en activos accesibles, aunque estén "escondidos".
