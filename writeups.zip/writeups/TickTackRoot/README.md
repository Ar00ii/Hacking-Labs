# TickTackRoot — The Hackers Labs

**Autor:** Carlos de la Cruz · ASIX 2
**Dificultad:** Fácil/Media · **Plataforma:** The Hackers Labs

> Resumen de la intrusión: FTP anónimo revela un usuario → fuerza bruta SSH → escalada de privilegios mediante binario SUID `timeout`.

---

## 1. Reconocimiento de puertos

Lanzamos un escaneo completo de Nmap contra la máquina objetivo (10.0.2.12).

```bash
nmap -sSVC -p- -Pn -n --min-rate 5000 -vvv 10.0.2.12
```

![Escaneo Nmap](images/01-nmap.png)

El escaneo muestra **tres puertos abiertos**: **21 (FTP)**, **22 (SSH)** y **80 (HTTP)**. El servicio FTP permite **login anónimo**, dato relevante para más adelante.

---

## 2. Enumeración web y FTP

La web (página por defecto de Apache2 en Ubuntu) no contiene nada de valor, ni en el navegador ni en su código fuente. Probamos entonces el FTP.

![Web por defecto de Apache](images/02-web.png)

Al conectarnos por FTP, el banner de bienvenida nos da una pista clave: **"Bienvenido Robin"**, lo que sugiere un posible nombre de usuario.

```bash
ftp 10.0.2.12
```

![Conexión FTP con pista del usuario](images/03-ftp.png)

---

## 3. Fuerza bruta SSH

Con el usuario `robin` como hipótesis, atacamos SSH con **Hydra** y `rockyou.txt`.

```bash
hydra -l robin -P /usr/share/wordlists/rockyou.txt.gz ssh://10.0.2.12
```

Hydra devuelve la contraseña: **`babyblue`**.

![Fuerza bruta SSH con Hydra](images/04-hydra.png)

---

## 4. Primera flag (user)

Nos conectamos por SSH, hacemos `ls -la` y leemos `user.txt` con `cat` para obtener la **flag de usuario**.

A continuación, `sudo -l` revela que `robin` puede ejecutar **`/usr/bin/timeout_suid`** con privilegios.

![Flag de usuario y sudo -l](images/05-userflag-sudo.png)

---

## 5. Escalada de privilegios (SUID timeout)

Comprobamos que el binario `/usr/bin/timeout_suid` tiene activado el **bit SUID** (confirmable con `find / -perm -4000 -type f 2>/dev/null`). Dado que `timeout` sirve para ejecutar otros comandos durante un tiempo determinado, lo aprovechamos para lanzar una shell heredando los privilegios del binario:

```bash
sudo /usr/bin/timeout_suid 7d /bin/bash
```

Esto nos abre una consola como **root**. Nos movemos a `/root` y leemos `root.txt` con `cat` para capturar la **flag final**.

![Escalada con timeout y flag de root](images/06-rootflag.png)

---

## Conclusión

La máquina muestra cómo un FTP anónimo puede filtrar información de usuarios y cómo un **binario con SUID que permite ejecución arbitraria** (`timeout`) facilita una escalada inmediata a root. Mitigaciones: deshabilitar el acceso anónimo a FTP, reforzar credenciales SSH y eliminar el bit SUID de binarios que permitan spawnear comandos.
