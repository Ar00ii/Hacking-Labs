# ZAPP — The Hackers Labs (CTF Challenge)

**Autor:** Carlos de la Cruz · ASIX 2
**Dificultad:** Media · **Plataforma:** The Hackers Labs

> Resumen de la intrusión: nombre de usuario filtrado en el título web → Base64 anidado en el HTML → `.rar` protegido crackeado con John → contraseña SSH → escalada mediante `sudo /bin/zsh`.

---

## 1. Reconocimiento de puertos

Escaneamos la máquina objetivo (10.0.2.18) con Nmap.

```bash
nmap -sSVC -p- -Pn -n --min-rate 5000 -vvv 10.0.2.18
```

![Escaneo Nmap](images/01-nmap.png)

El escaneo devuelve **tres puertos abiertos**: **21 (FTP)**, **22 (SSH)** y **80 (HTTP)**. El título de la web ya filtra un dato útil: el nombre **`zappskred`**, que anotamos porque puede servir como usuario más adelante.

---

## 2. Base64 anidado en el código fuente

La web no muestra nada relevante a simple vista, pero al inspeccionar el HTML encontramos una cadena **Base64**. La peculiaridad es que está **codificada varias veces de forma anidada**, así que creamos un pequeño script que decodifica en bucle hasta agotar las capas.

```bash
#!/bin/bash
cadena="VjFST1YyRkhVa2xUYmxwYVRURmFiMXBGYUV0a2JWSjBWbTF3WVZkRk1VeERaejA5Q2c="
while echo "$cadena" | base64 -d &>/dev/null; do
    cadena=$(echo "$cadena" | base64 -d)
done
echo "$cadena"
```

![Hash Base64 en el HTML](images/02-base64-html.png)

Le damos permisos de ejecución (`chmod +x bash64`) y lo lanzamos.

![Permisos de ejecución del script](images/03-chmod.png)

El resultado tras desanidar todas las capas es la palabra **`cuatrocuatroveces`**, el único dato aprovechable.

![Resultado de la decodificación](images/04-resultado.png)

---

## 3. Directorio oculto y archivo .rar

Buscamos `cuatrocuatroveces` como ruta web y encontramos un **archivo `.rar`** descargable (`Sup3rP4ss.rar`).

```bash
wget http://10.0.2.18/cuatrocuatroveces/Sup3rP4ss.rar
```

![Index del directorio y descarga del rar](images/05-rar.png)

---

## 4. Crackeo del .rar con John

El `.rar` está protegido con contraseña. Extraemos su hash con **rar2john** y lo crackeamos con **John the Ripper** usando `rockyou.txt`.

```bash
rar2john Sup3rP4ss.rar > rar.hash
john --wordlist=/usr/share/wordlists/rockyou.txt rar.hash
```

John recupera la contraseña del archivo: **`reema`**.

![rar2john y John the Ripper](images/06-john.png)

Descomprimimos con `unrar x Sup3rP4ss.rar`, introducimos `reema` y obtenemos un `.txt`. Al leerlo con `cat`, nos da la pista **`3spuM4`** (la palabra "espuma" en leet), candidata a contraseña SSH.

![Extracción del rar y contenido](images/07-unrar.png)

---

## 5. Primera flag (user)

Probamos a conectarnos por SSH con el usuario `zappskred` (recordado del título web) y la contraseña obtenida. La combinación es válida y entramos.

Con un simple `ls` y `cat user.txt` capturamos la **primera flag**.

![Acceso SSH y flag de usuario](images/08-ssh-userflag.png)

---

## 6. Escalada de privilegios (sudo /bin/zsh)

El usuario tiene permiso para ejecutar **`/bin/zsh` como root**, así que abrimos directamente una shell privilegiada:

```bash
sudo /bin/zsh
whoami   # -> root
```

Confirmamos con `whoami` que somos **root**, listamos con `ls -la` y leemos `root.txt` con `cat` para obtener la **flag final**.

![Escalada con zsh y flag de root](images/09-rootflag.png)

---

## Conclusión

ZAPP encadena varias técnicas de ofuscación (un nombre de usuario "a la vista" en el título y un Base64 multicapa) con el crackeo de un archivo comprimido protegido. La escalada final es trivial por un permiso `sudo` sobre un intérprete (`zsh`). Mitigaciones: no exponer nombres de usuario en metadatos, no almacenar secretos ofuscados como si fueran cifrados y restringir `sudo` sobre shells.
