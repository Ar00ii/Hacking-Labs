# Dragon — The Hackers Labs

**Autor:** Carlos de la Cruz · ASIX 2
**Dificultad:** Fácil/Media · **Plataforma:** The Hackers Labs

> Resumen de la intrusión: enumeración web sin frutos → fuerza bruta SSH directa → escalada de privilegios mediante `sudo vim`.

---

## 1. Reconocimiento de puertos

Comenzamos con un escaneo completo de Nmap sobre la IP objetivo para descubrir servicios.

```bash
nmap -sSVC -p- -Pn -n --min-rate 5000 -vvv 10.0.2.8
```

![Escaneo Nmap inicial](images/01-nmap.png)

El escaneo muestra **dos puertos abiertos**: el **22 (SSH)** con OpenSSH 9.6p1 y el **80 (HTTP)** servido por Apache 2.4.58. Al disponer de servicio web, lo inspeccionamos primero en el navegador.

![Web "La Máquina del Dragón"](images/02-web.png)

---

## 2. Enumeración web

La página de bienvenida no expone nada relevante, ni siquiera en el código fuente. Lanzamos **Gobuster** para descubrir rutas ocultas y obtenemos el directorio `secret`.

```bash
gobuster dir -u http://10.0.2.8/ -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt
```

![Gobuster y página secret](images/03-gobuster-secret.png)

`/secret/` solo contiene un acertijo temático sin información explotable. Como la vía web se agota, redirigimos el ataque al otro servicio disponible: SSH.

---

## 3. Fuerza bruta SSH

Atacamos directamente el puerto 22 con **Hydra** y el diccionario `rockyou.txt`, probando el usuario `dragon`.

```bash
hydra -l dragon -P /usr/share/wordlists/rockyou.txt.gz ssh://10.0.2.8
```

Hydra devuelve una combinación válida: **`dragon:shadow`**.

![Fuerza bruta SSH con Hydra](images/04-hydra.png)

---

## 4. Primera flag (user)

Nos conectamos por SSH como `dragon`, listamos el directorio y leemos `user.txt` con `cat` para obtener la **flag de usuario**.

![Conexión SSH y flag de usuario](images/05-ssh-userflag.png)

---

## 5. Escalada de privilegios (sudo vim)

Ejecutamos `sudo -l` y descubrimos que `dragon` puede ejecutar **`/usr/bin/vim` como root sin contraseña** (`NOPASSWD`). Vim permite lanzar comandos del sistema desde su modo de comandos, así que es una vía directa de escalada.

![Comprobación de sudo -l](images/06-sudo-l.png)

Abrimos Vim con privilegios y, una vez dentro, escribimos el siguiente comando para spawnear una shell con permisos de root:

```vim
:!/bin/bash
```

![Spawneo de shell desde Vim](images/07-vim-shell.png)

Al ejecutarlo obtenemos una consola como **root**.

![Shell de root obtenida](images/08-root.png)

---

## 6. Flag final (root)

Listamos `/root`, localizamos `root.txt` y lo leemos con `cat` para capturar la **flag de root**.

![Flag de root](images/09-rootflag.png)

---

## Conclusión

Dragon es un caso clásico de escalada vía **GTFOBins**: un binario interactivo (`vim`) con permiso `sudo NOPASSWD` permite saltar a root de forma trivial. La lección principal es no conceder privilegios `sudo` sobre editores ni intérpretes, y reforzar las contraseñas SSH para evitar la fuerza bruta inicial.
