# Inj3ctCrew — The Hackers Labs

**Autor:** Carlos de la Cruz · ASIX 2
**Dificultad:** Media · **Plataforma:** The Hackers Labs

> Resumen de la intrusión: enumeración web → credenciales filtradas en backups → ejecución de comandos vía panel web → fuerza bruta SSH → escalada de privilegios mediante `sudo find`.

---

## 1. Reconocimiento de puertos

Lanzamos un escaneo completo con Nmap para identificar los servicios expuestos. Las opciones empleadas son: `-sSVC` (descubrimiento de versiones + scripts por defecto), `-p-` (los 65 535 puertos), `-Pn` (omite el ping inicial asumiendo que el host está activo), `-n` (sin resolución DNS) y `--min-rate 5000` para acelerar el barrido.

```bash
nmap -sSVC -p- -Pn -n --min-rate 5000 -vvv 10.0.2.4
```

![Escaneo Nmap inicial](images/01-nmap.png)

El escaneo revela **dos puertos abiertos**: el **22 (SSH)** sobre OpenSSH 9.6p1 y el **80 (HTTP)** servido por Apache 2.4.58. Al existir un servicio web, comenzamos la enumeración por ahí.

![Resultado de puertos abiertos](images/02-puertos.png)

---

## 2. Enumeración web

La página principal no muestra nada aprovechable a simple vista (solo el mensaje "SIGUE BUSCANDO"). Sin embargo, al inspeccionar el código fuente encontramos una cadena en **Base64** oculta en el HTML, candidata a contener información útil.

![Inspección del código fuente](images/03-web-inspeccion.png)

Decodificamos la cadena Base64. El texto resultante nos avisa de que **el directorio de respaldo ha sido comprometido**, lo que orienta la siguiente fase: localizar ese directorio.

![Decodificación Base64](images/04-base64.png)

---

## 3. Fuzzing de directorios

Con **Gobuster** enumeramos rutas y extensiones (`html`, `php`, `txt`). El escaneo devuelve varios archivos interesantes; el más prometedor es `backup.php`.

```bash
gobuster dir -u http://10.0.2.5/ -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt -x html,php,txt
```

![Resultado de Gobuster](images/05-gobuster.png)

---

## 4. Credenciales filtradas

`backup.php` muestra el mensaje "PWNED DIRECTORY" y, de nuevo, no parece útil a primera vista. Inspeccionando el HTML aparece un comentario del atacante que apunta a un segundo archivo: `PwnedCredentials.html`.

![backup.php inspeccionado](images/06-backupphp.png)

Esa página filtra unas credenciales del panel administrativo: el usuario **Admin** y una contraseña en formato hash MD5.

![Credenciales filtradas](images/07-credenciales.png)

Llevamos el hash a **CrackStation**, que lo identifica como MD5 y devuelve la contraseña en claro: **`qwerty`**.

![Crackeo del hash en CrackStation](images/08-crackstation.png)

---

## 5. Acceso al panel y ejecución de comandos

Con las credenciales `Admin:qwerty` accedemos a `login.php`.

![Login del panel](images/09-login.png)

El panel de control incluye un campo para **ejecutar comandos del sistema** (Remote Command Execution). Lo usamos para leer `/etc/passwd` y enumerar usuarios locales.

![Panel de control con ejecución de comandos](images/10-panel.png)

En la salida vemos que el usuario **`nolen11`** tiene asignada `/bin/bash`, es decir, es una cuenta de login real y un buen objetivo para conseguir acceso interactivo.

![Contenido de /etc/passwd](images/11-passwd.png)

---

## 6. Fuerza bruta SSH

Conocido el usuario, atacamos SSH con **Hydra** usando el diccionario `rockyou.txt`.

```bash
hydra -l nolen11 -P /usr/share/wordlists/rockyou.txt.gz ssh://10.0.2.5
```

Hydra encuentra la contraseña: **`987654321`**.

![Fuerza bruta SSH con Hydra](images/12-hydra.png)

---

## 7. Primera flag (user)

Nos conectamos por SSH y, con `ls -la`, localizamos `user.txt`. Un `cat` nos da la **flag de usuario**.

![Conexión SSH y flag de usuario](images/13-userflag.png)

---

## 8. Escalada de privilegios (sudo find)

Ejecutamos `sudo -l` para revisar qué puede correr el usuario con privilegios. Resulta que `nolen11` puede ejecutar **`/usr/bin/find` como root sin contraseña** (`NOPASSWD`).

`find` permite lanzar comandos externos mediante `-exec`, así que abusamos de ese permiso para abrir una shell con privilegios de root:

```bash
sudo find . -exec /bin/bash \; -quit
```

Ya como root, nos movemos a `/root`, listamos el contenido y leemos `root.txt` para obtener la **flag final**.

![Escalada con sudo find y flag de root](images/14-rootflag.png)

---

## Conclusión

La máquina encadena malas prácticas habituales: información sensible expuesta en directorios de backup, credenciales débiles reutilizadas y un panel web con ejecución de comandos sin restringir. La escalada final se debe a un permiso `sudo` demasiado amplio sobre un binario (`find`) que permite spawnear shells. Mitigaciones: retirar backups del webroot, no almacenar credenciales en HTML, sanear/eliminar el panel de comandos y restringir los privilegios `sudo`.
